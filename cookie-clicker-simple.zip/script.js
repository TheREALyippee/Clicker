// Simple click counter
(function(){
  const circle = document.getElementById('circle');
  const countEl = document.getElementById('count');
  let count = 0;

  function update() {
    countEl.textContent = `Clicks: ${count}`;
  }

  circle.addEventListener('click', () => {
    count++;
    update();

    // quick visual pulse
    circle.animate([
      { transform: 'translate(-50%,-50%) scale(1)' },
      { transform: 'translate(-50%,-50%) scale(1.06)' },
      { transform: 'translate(-50%,-50%) scale(1)' }
    ], {
      duration: 140,
      easing: 'ease-out'
    });
  });

  // keyboard accessibility: Space or Enter activates
  circle.addEventListener('keydown', (e) => {
    if(e.code === 'Space' || e.code === 'Enter'){
      e.preventDefault();
      circle.click();
    }
  });

  // make the circle focusable
  circle.tabIndex = 0;

  update();
})();
