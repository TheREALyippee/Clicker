# Simple Clicker

A tiny single-file web app that counts clicks. White background, black circle in the center, and a text on top showing how many times you clicked.

## Files
- `index.html` — page
- `style.css` — minimal styling
- `script.js` — click counter logic

## To run locally
Open `index.html` in a browser (double-click or serve with a static server like `python -m http.server`).

## To push to GitHub
1. Create a repo on GitHub.
2. In this folder run:
```bash
git init
git add .
git commit -m "Add simple clicker"
git branch -M main
git remote add origin <your-repo-url>
git push -u origin main
```

